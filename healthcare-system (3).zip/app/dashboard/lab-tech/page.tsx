"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { LabStats } from "@/components/dashboard/lab-stats"
import { PendingTests } from "@/components/dashboard/pending-tests"
import { LabQuickActions } from "@/components/dashboard/lab-quick-actions"
import { TestResults } from "@/components/dashboard/test-results"

export default function LabTechDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }
    const parsedUser = JSON.parse(userData)
    if (parsedUser.role !== "lab-tech") {
      router.push("/")
      return
    }
    setUser(parsedUser)
  }, [router])

  if (!user) return null

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}</h1>
          <p className="text-gray-600">{user.center} • Lab Technician Dashboard</p>
        </div>

        <LabStats />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <PendingTests />
            <TestResults />
          </div>
          <div>
            <LabQuickActions />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
