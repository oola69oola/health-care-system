"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { PharmacyStats } from "@/components/dashboard/pharmacy-stats"
import { PrescriptionQueue } from "@/components/dashboard/prescription-queue"
import { PharmacyQuickActions } from "@/components/dashboard/pharmacy-quick-actions"
import { InventoryStatus } from "@/components/dashboard/inventory-status"

export default function PharmacistDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }
    const parsedUser = JSON.parse(userData)
    if (parsedUser.role !== "pharmacist") {
      router.push("/")
      return
    }
    setUser(parsedUser)
  }, [router])

  if (!user) return null

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}</h1>
          <p className="text-gray-600">{user.center} • Pharmacist Dashboard</p>
        </div>

        <PharmacyStats />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <PrescriptionQueue />
            <InventoryStatus />
          </div>
          <div>
            <PharmacyQuickActions />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
