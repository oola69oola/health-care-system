"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { AdminStats } from "@/components/dashboard/admin-stats"
import { SystemOverview } from "@/components/dashboard/system-overview"
import { AdminQuickActions } from "@/components/dashboard/admin-quick-actions"
import { UserManagement } from "@/components/dashboard/user-management"

export default function AdminDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }
    const parsedUser = JSON.parse(userData)
    if (parsedUser.role !== "admin") {
      router.push("/")
      return
    }
    setUser(parsedUser)
  }, [router])

  if (!user) return null

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}</h1>
          <p className="text-gray-600">System Administrator Dashboard</p>
        </div>

        <AdminStats />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <SystemOverview />
            <UserManagement />
          </div>
          <div>
            <AdminQuickActions />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
