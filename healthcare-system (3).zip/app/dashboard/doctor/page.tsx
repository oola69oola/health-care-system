"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { DoctorStats } from "@/components/dashboard/doctor-stats"
import { RecentPatients } from "@/components/dashboard/recent-patients"
import { DoctorQuickActions } from "@/components/dashboard/doctor-quick-actions"
import { UpcomingAppointments } from "@/components/dashboard/upcoming-appointments"

export default function DoctorDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }
    const parsedUser = JSON.parse(userData)
    if (parsedUser.role !== "doctor") {
      router.push("/")
      return
    }
    setUser(parsedUser)
  }, [router])

  if (!user) return null

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}</h1>
          <p className="text-gray-600">{user.center} • Doctor Dashboard</p>
        </div>

        <DoctorStats />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <RecentPatients />
            <UpcomingAppointments />
          </div>
          <div>
            <DoctorQuickActions />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
