"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { NurseStats } from "@/components/dashboard/nurse-stats"
import { PatientVitals } from "@/components/dashboard/patient-vitals"
import { NurseQuickActions } from "@/components/dashboard/nurse-quick-actions"
import { MedicationSchedule } from "@/components/dashboard/medication-schedule"

export default function NurseDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }
    const parsedUser = JSON.parse(userData)
    if (parsedUser.role !== "nurse") {
      router.push("/")
      return
    }
    setUser(parsedUser)
  }, [router])

  if (!user) return null

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}</h1>
          <p className="text-gray-600">{user.center} • Nurse Dashboard</p>
        </div>

        <NurseStats />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <PatientVitals />
            <MedicationSchedule />
          </div>
          <div>
            <NurseQuickActions />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
