import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"

// Mock user data - in production, this would query the database
const mockUsers = [
  {
    id: "660e8400-e29b-41d4-a716-446655440001",
    email: "dr.adebayo@phc.oyo.gov.ng",
    password_hash: "$2b$10$hash1",
    full_name: "Dr. Adebayo Johnson",
    role: "doctor",
    phc_center_id: "550e8400-e29b-41d4-a716-446655440001",
    center_name: "Agodi PHC Center",
  },
]

export async function POST(request: NextRequest) {
  try {
    const { email, password, role, center } = await request.json()

    // Validate input
    if (!email || !password || !role || !center) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    // In production, query the database
    // const user = await db.query('SELECT * FROM users WHERE email = $1', [email])

    // Mock authentication
    const user = mockUsers.find((u) => u.email === email)

    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // In production, verify password hash
    // const isValidPassword = await bcrypt.compare(password, user.password_hash)

    // Mock password validation
    const isValidPassword = password === "password123"

    if (!isValidPassword) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
        center: user.center_name,
      },
      process.env.JWT_SECRET || "fallback-secret",
      { expiresIn: "24h" },
    )

    // Log successful login (audit trail)
    console.log(`User ${user.email} logged in successfully at ${new Date().toISOString()}`)

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        name: user.full_name,
        email: user.email,
        role: user.role,
        center: user.center_name,
      },
      token,
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
