import { type NextRequest, NextResponse } from "next/server"

// Mock patient data - in production, this would query the database
const mockPatients = [
  {
    id: "770e8400-e29b-41d4-a716-446655440001",
    patient_id: "PHC001001",
    name: "Adunni Olatunji",
    age: 34,
    gender: "Female",
    phone: "+234 803 123 4567",
    lastVisit: "2024-01-15",
    status: "Active",
    center: "Agodi PHC",
    condition: "Hypertension",
    initials: "AO",
  },
  {
    id: "770e8400-e29b-41d4-a716-446655440002",
    patient_id: "PHC002001",
    name: "Tunde Ogundimu",
    age: 45,
    gender: "Male",
    phone: "+234 805 987 6543",
    lastVisit: "2024-01-12",
    status: "Follow-up",
    center: "Bodija PHC",
    condition: "Diabetes",
    initials: "TO",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search") || ""
    const status = searchParams.get("status") || "all"
    const center = searchParams.get("center") || "all"

    // Filter patients based on query parameters
    const filteredPatients = mockPatients.filter((patient) => {
      const matchesSearch = patient.name.toLowerCase().includes(search.toLowerCase()) || patient.phone.includes(search)
      const matchesStatus = status === "all" || patient.status.toLowerCase() === status
      const matchesCenter = center === "all" || patient.center === center

      return matchesSearch && matchesStatus && matchesCenter
    })

    return NextResponse.json({
      success: true,
      patients: filteredPatients,
      total: filteredPatients.length,
    })
  } catch (error) {
    console.error("Error fetching patients:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const patientData = await request.json()

    // Validate required fields
    const requiredFields = ["firstName", "lastName", "dateOfBirth", "gender", "phone"]
    for (const field of requiredFields) {
      if (!patientData[field]) {
        return NextResponse.json({ error: `${field} is required` }, { status: 400 })
      }
    }

    // In production, insert into database
    // const newPatient = await db.query('INSERT INTO patients (...) VALUES (...)')

    // Mock response
    const newPatient = {
      id: `770e8400-e29b-41d4-a716-${Date.now()}`,
      patient_id: `PHC${Date.now()}`,
      ...patientData,
      status: "Active",
      created_at: new Date().toISOString(),
    }

    return NextResponse.json(
      {
        success: true,
        patient: newPatient,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Error creating patient:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
