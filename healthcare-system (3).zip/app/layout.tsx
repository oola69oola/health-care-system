import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { NDPRBanner } from "@/components/compliance/ndpr-banner"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "PHC Collaboration System - Ibadan North LGA",
  description:
    "Web-based collaborative healthcare system for Primary Health Care centers in Ibadan North Local Government Area",
  keywords: "healthcare, PHC, Nigeria, Ibadan, collaboration, NDPR",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        {children}
        <NDPRBanner />
        <Toaster />
      </body>
    </html>
  )
}
