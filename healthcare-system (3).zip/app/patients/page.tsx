"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { PatientList } from "@/components/patients/patient-list"
import { PatientFilters } from "@/components/patients/patient-filters"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function PatientsPage() {
  const router = useRouter()
  const [filters, setFilters] = useState({
    search: "",
    status: "all",
    center: "all",
  })

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Patient Records</h1>
            <p className="text-gray-600">Manage and access patient information</p>
          </div>
          <Button onClick={() => router.push("/patients/new")} className="flex items-center space-x-2">
            <Plus className="mr-2 h-4 w-4" />
            New Patient
          </Button>
        </div>

        <PatientFilters filters={filters} onFiltersChange={setFilters} />
        <PatientList filters={filters} />
      </div>
    </DashboardLayout>
  )
}
