"use client"

import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { ReferralList } from "@/components/referrals/referral-list"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function ReferralsPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Referral Management</h1>
            <p className="text-gray-600">Track and manage patient referrals between PHC centers</p>
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Referral
          </Button>
        </div>

        <ReferralList />
      </div>
    </DashboardLayout>
  )
}
