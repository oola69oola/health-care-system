-- Seed data for PHC Collaboration System
-- Insert PHC Centers in Ibadan North LGA

INSERT INTO phc_centers (id, name, code, address, phone, email) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'Agodi PHC Center', 'AGD001', 'Agodi Area, Ibadan North LGA', '+234 802 123 4567', 'agodi@phc.oyo.gov.ng'),
('550e8400-e29b-41d4-a716-446655440002', 'Bodija PHC Center', 'BOD002', 'Bodija Estate, Ibadan North LGA', '+234 803 234 5678', 'bodija@phc.oyo.gov.ng'),
('550e8400-e29b-41d4-a716-446655440003', 'Inalende PHC Center', 'INA003', 'Inalende Area, Ibadan North LGA', '+234 804 345 6789', 'inalende@phc.oyo.gov.ng'),
('550e8400-e29b-41d4-a716-446655440004', 'Mokola PHC Center', 'MOK004', 'Mokola Area, Ibadan North LGA', '+234 805 456 7890', 'mokola@phc.oyo.gov.ng'),
('550e8400-e29b-41d4-a716-446655440005', 'Sango PHC Center', 'SAN005', 'Sango Area, Ibadan North LGA', '+234 806 567 8901', 'sango@phc.oyo.gov.ng');

-- Insert sample users (healthcare professionals)
INSERT INTO users (id, email, password_hash, full_name, role, phc_center_id, phone, data_consent, consent_date) VALUES
('660e8400-e29b-41d4-a716-446655440001', 'dr.adebayo@phc.oyo.gov.ng', '$2b$10$hash1', 'Dr. Adebayo Johnson', 'doctor', '550e8400-e29b-41d4-a716-446655440001', '+234 807 123 4567', true, CURRENT_TIMESTAMP),
('660e8400-e29b-41d4-a716-446655440002', 'dr.fatima@phc.oyo.gov.ng', '$2b$10$hash2', 'Dr. Fatima Bello', 'doctor', '550e8400-e29b-41d4-a716-446655440002', '+234 808 234 5678', true, CURRENT_TIMESTAMP),
('660e8400-e29b-41d4-a716-446655440003', 'nurse.aisha@phc.oyo.gov.ng', '$2b$10$hash3', 'Nurse Aisha Mahmud', 'nurse', '550e8400-e29b-41d4-a716-446655440005', '+234 809 345 6789', true, CURRENT_TIMESTAMP),
('660e8400-e29b-41d4-a716-446655440004', 'dr.kemi@phc.oyo.gov.ng', '$2b$10$hash4', 'Dr. Kemi Ogundimu', 'doctor', '550e8400-e29b-41d4-a716-446655440004', '+234 810 456 7890', true, CURRENT_TIMESTAMP),
('660e8400-e29b-41d4-a716-446655440005', 'admin.system@phc.oyo.gov.ng', '$2b$10$hash5', 'System Administrator', 'admin', '550e8400-e29b-41d4-a716-446655440001', '+234 811 567 8901', true, CURRENT_TIMESTAMP);

-- Insert sample patients
INSERT INTO patients (id, patient_id, first_name, last_name, date_of_birth, gender, phone, address, primary_phc_center_id, blood_group, data_consent, consent_date) VALUES
('770e8400-e29b-41d4-a716-446655440001', 'PHC001001', 'Adunni', 'Olatunji', '1990-03-15', 'Female', '+234 803 123 4567', 'No. 15 Agodi Street, Ibadan', '550e8400-e29b-41d4-a716-446655440001', 'O+', true, CURRENT_TIMESTAMP),
('770e8400-e29b-41d4-a716-446655440002', 'PHC002001', 'Tunde', 'Ogundimu', '1979-07-22', 'Male', '+234 805 987 6543', 'No. 8 Bodija Estate, Ibadan', '550e8400-e29b-41d4-a716-446655440002', 'A+', true, CURRENT_TIMESTAMP),
('770e8400-e29b-41d4-a716-446655440003', 'PHC001002', 'Kemi', 'Adebayo', '1996-11-08', 'Female', '+234 807 456 7890', 'No. 22 Agodi GRA, Ibadan', '550e8400-e29b-41d4-a716-446655440001', 'B+', true, CURRENT_TIMESTAMP),
('770e8400-e29b-41d4-a716-446655440004', 'PHC004001', 'Bisi', 'Afolabi', '1972-05-30', 'Female', '+234 809 234 5678', 'No. 5 Mokola Avenue, Ibadan', '550e8400-e29b-41d4-a716-446655440004', 'AB+', true, CURRENT_TIMESTAMP);

-- Insert sample medical records
INSERT INTO medical_records (patient_id, phc_center_id, attending_physician_id, chief_complaint, diagnosis, treatment_plan, vital_signs) VALUES
('770e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440001', 'High blood pressure', 'Hypertension Stage 1', 'Lifestyle modification, antihypertensive medication', '{"bp": "140/90", "hr": "78", "temp": "36.5", "weight": "68"}'),
('770e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440002', 'Frequent urination and thirst', 'Type 2 Diabetes Mellitus', 'Metformin, dietary counseling, regular monitoring', '{"bp": "130/85", "hr": "82", "temp": "36.8", "weight": "75", "glucose": "180"}'),
('770e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440001', 'Routine prenatal visit', 'Normal pregnancy - 24 weeks', 'Prenatal vitamins, regular check-ups', '{"bp": "110/70", "hr": "88", "temp": "36.6", "weight": "62"}');

-- Insert sample referrals
INSERT INTO referrals (referral_number, patient_id, referring_center_id, receiving_center_id, referring_physician_id, referral_reason, urgency_level, status) VALUES
('REF2024001', '770e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440001', 'Specialist cardiology consultation for hypertension management', 'High', 'Pending'),
('REF2024002', '770e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440004', 'Diabetes management and monitoring', 'Medium', 'In Progress'),
('REF2024003', '770e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440004', 'Cardiac assessment and evaluation', 'Medium', 'Completed');

-- Insert sample messages
INSERT INTO messages (sender_id, recipient_id, subject, content, message_type, referral_id) VALUES
('660e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440001', 'Referral Update', 'Patient referral completed successfully. Blood pressure is now under control.', 'referral', (SELECT id FROM referrals WHERE referral_number = 'REF2024001')),
('660e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440001', 'Lab Results', 'Lab results are ready for review for patient Kemi Adebayo.', 'consultation', NULL),
('660e8400-e29b-41d4-a716-446655440005', '660e8400-e29b-41d4-a716-446655440001', 'System Maintenance', 'System maintenance scheduled for tonight from 11 PM to 2 AM.', 'general', NULL);

-- Insert system settings
INSERT INTO system_settings (setting_key, setting_value, description, updated_by) VALUES
('data_retention_period', '2555', 'Default data retention period in days (7 years)', '660e8400-e29b-41d4-a716-446655440005'),
('session_timeout', '3600', 'Session timeout in seconds (1 hour)', '660e8400-e29b-41d4-a716-446655440005'),
('max_file_upload_size', '10485760', 'Maximum file upload size in bytes (10MB)', '660e8400-e29b-41d4-a716-446655440005'),
('enable_audit_logging', 'true', 'Enable comprehensive audit logging', '660e8400-e29b-41d4-a716-446655440005');
