import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Calendar, Clock } from "lucide-react"

const appointments = [
  {
    id: "1",
    patient: "Bisi Afolabi",
    time: "3:00 PM",
    type: "Follow-up",
    duration: "30 min",
    status: "Confirmed",
    initials: "BA",
  },
  {
    id: "2",
    patient: "Ibrahim Yusuf",
    time: "3:30 PM",
    type: "Consultation",
    duration: "45 min",
    status: "Pending",
    initials: "IY",
  },
  {
    id: "3",
    patient: "Folake Adeyemi",
    time: "4:15 PM",
    type: "Check-up",
    duration: "30 min",
    status: "Confirmed",
    initials: "FA",
  },
]

export function UpcomingAppointments() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Calendar className="h-5 w-5" />
          <span>Upcoming Appointments</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {appointments.map((appointment) => (
            <div key={appointment.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center space-x-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-green-100 text-green-600">{appointment.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium">{appointment.patient}</h4>
                  <p className="text-sm text-gray-600">{appointment.type}</p>
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    <Clock className="h-3 w-3" />
                    <span>
                      {appointment.time} ({appointment.duration})
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={appointment.status === "Confirmed" ? "default" : "secondary"}>
                  {appointment.status}
                </Badge>
                <Button variant="outline" size="sm">
                  View
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
