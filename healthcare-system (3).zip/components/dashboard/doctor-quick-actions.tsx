"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Send, Users, Loader2, Calendar } from "lucide-react"

const actions = [
  {
    title: "New Consultation",
    description: "Start patient consultation",
    icon: Plus,
    href: "/patients/new",
    color: "bg-blue-500 hover:bg-blue-600",
  },
  {
    title: "Create Referral",
    description: "Refer patient to specialist",
    icon: Send,
    href: "/referrals/new",
    color: "bg-green-500 hover:bg-green-600",
  },
  {
    title: "View Patients",
    description: "Browse patient records",
    icon: Users,
    href: "/patients",
    color: "bg-purple-500 hover:bg-purple-600",
  },
  {
    title: "Schedule Appointment",
    description: "Book patient appointment",
    icon: Calendar,
    href: "/appointments",
    color: "bg-orange-500 hover:bg-orange-600",
  },
]

export function DoctorQuickActions() {
  const router = useRouter()
  const [loadingAction, setLoadingAction] = useState<string | null>(null)

  const handleActionClick = async (action: (typeof actions)[0]) => {
    setLoadingAction(action.title)
    await new Promise((resolve) => setTimeout(resolve, 300))
    router.push(action.href)
    setLoadingAction(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action) => (
            <Button
              key={action.title}
              variant="outline"
              className="w-full justify-start h-auto p-4 bg-transparent hover:bg-gray-50"
              onClick={() => handleActionClick(action)}
              disabled={loadingAction === action.title}
            >
              <div className={`p-2 rounded-md mr-3 ${action.color}`}>
                {loadingAction === action.title ? (
                  <Loader2 className="h-4 w-4 text-white animate-spin" />
                ) : (
                  <action.icon className="h-4 w-4 text-white" />
                )}
              </div>
              <div className="text-left">
                <div className="font-medium">{action.title}</div>
                <div className="text-sm text-gray-500">{action.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
