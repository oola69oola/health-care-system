"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Send, FileText, Users, Loader2 } from "lucide-react"

const actions = [
  {
    title: "New Patient Record",
    description: "Register a new patient",
    icon: Plus,
    href: "/patients/new",
    color: "bg-blue-500 hover:bg-blue-600",
  },
  {
    title: "Create Referral",
    description: "Refer patient to another center",
    icon: Send,
    href: "/referrals/new",
    color: "bg-green-500 hover:bg-green-600",
  },
  {
    title: "View All Patients",
    description: "Browse patient records",
    icon: Users,
    href: "/patients",
    color: "bg-purple-500 hover:bg-purple-600",
  },
  {
    title: "Generate Report",
    description: "Create activity report",
    icon: FileText,
    href: "/reports",
    color: "bg-orange-500 hover:bg-orange-600",
  },
]

export function QuickActions() {
  const router = useRouter()
  const [loadingAction, setLoadingAction] = useState<string | null>(null)

  const handleActionClick = async (action: (typeof actions)[0]) => {
    setLoadingAction(action.title)

    // Simulate loading for better UX
    await new Promise((resolve) => setTimeout(resolve, 300))

    router.push(action.href)
    setLoadingAction(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action) => (
            <Button
              key={action.title}
              variant="outline"
              className="w-full justify-start h-auto p-4 bg-transparent hover:bg-gray-50 transition-colors"
              onClick={() => handleActionClick(action)}
              disabled={loadingAction === action.title}
            >
              <div className={`p-2 rounded-md mr-3 ${action.color} transition-colors`}>
                {loadingAction === action.title ? (
                  <Loader2 className="h-4 w-4 text-white animate-spin" />
                ) : (
                  <action.icon className="h-4 w-4 text-white" />
                )}
              </div>
              <div className="text-left">
                <div className="font-medium">{action.title}</div>
                <div className="text-sm text-gray-500">{action.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
