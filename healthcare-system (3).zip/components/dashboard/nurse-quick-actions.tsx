"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Activity, Thermometer, Pill, FileText, Loader2 } from "lucide-react"

const actions = [
  {
    title: "Record Vitals",
    description: "Take patient vital signs",
    icon: Activity,
    href: "/vitals/new",
    color: "bg-red-500 hover:bg-red-600",
  },
  {
    title: "Temperature Check",
    description: "Record temperature",
    icon: Thermometer,
    href: "/vitals/temperature",
    color: "bg-orange-500 hover:bg-orange-600",
  },
  {
    title: "Medication Admin",
    description: "Administer medications",
    icon: Pill,
    href: "/medications",
    color: "bg-green-500 hover:bg-green-600",
  },
  {
    title: "Nursing Notes",
    description: "Add nursing observations",
    icon: FileText,
    href: "/notes/new",
    color: "bg-purple-500 hover:bg-purple-600",
  },
]

export function NurseQuickActions() {
  const router = useRouter()
  const [loadingAction, setLoadingAction] = useState<string | null>(null)

  const handleActionClick = async (action: (typeof actions)[0]) => {
    setLoadingAction(action.title)
    await new Promise((resolve) => setTimeout(resolve, 300))
    router.push(action.href)
    setLoadingAction(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action) => (
            <Button
              key={action.title}
              variant="outline"
              className="w-full justify-start h-auto p-4 bg-transparent hover:bg-gray-50"
              onClick={() => handleActionClick(action)}
              disabled={loadingAction === action.title}
            >
              <div className={`p-2 rounded-md mr-3 ${action.color}`}>
                {loadingAction === action.title ? (
                  <Loader2 className="h-4 w-4 text-white animate-spin" />
                ) : (
                  <action.icon className="h-4 w-4 text-white" />
                )}
              </div>
              <div className="text-left">
                <div className="font-medium">{action.title}</div>
                <div className="text-sm text-gray-500">{action.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
