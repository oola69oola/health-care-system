import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const activities = [
  {
    id: 1,
    type: "referral",
    patient: "Adunni Olatunji",
    action: "Referred to Bodija PHC for specialist consultation",
    time: "2 hours ago",
    status: "pending",
    initials: "AO",
  },
  {
    id: 2,
    type: "message",
    patient: "Kemi Adebayo",
    action: "New message from Dr. Fatima regarding treatment plan",
    time: "4 hours ago",
    status: "unread",
    initials: "KA",
  },
  {
    id: 3,
    type: "record",
    patient: "Tunde Ogundimu",
    action: "Medical record updated with lab results",
    time: "6 hours ago",
    status: "completed",
    initials: "TO",
  },
  {
    id: 4,
    type: "referral",
    patient: "Bisi Afolabi",
    action: "Referral completed - patient seen at Mokola PHC",
    time: "1 day ago",
    status: "completed",
    initials: "BA",
  },
]

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-4">
              <Avatar className="h-10 w-10">
                <AvatarFallback className="bg-blue-100 text-blue-600">{activity.initials}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900">{activity.patient}</p>
                  <Badge
                    variant={
                      activity.status === "completed"
                        ? "default"
                        : activity.status === "pending"
                          ? "secondary"
                          : "destructive"
                    }
                  >
                    {activity.status}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">{activity.action}</p>
                <p className="text-xs text-gray-400">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
