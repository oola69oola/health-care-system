import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Eye } from "lucide-react"

const recentPatients = [
  {
    id: "1",
    name: "Adunni Olatunji",
    age: 34,
    condition: "Hypertension Follow-up",
    time: "10:30 AM",
    status: "Completed",
    initials: "AO",
  },
  {
    id: "2",
    name: "Tunde Ogundimu",
    age: 45,
    condition: "Diabetes Check",
    time: "11:15 AM",
    status: "In Progress",
    initials: "TO",
  },
  {
    id: "3",
    name: "Kemi Adebayo",
    age: 28,
    condition: "Prenatal Visit",
    time: "2:00 PM",
    status: "Scheduled",
    initials: "KA",
  },
]

export function RecentPatients() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Today's Patients</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentPatients.map((patient) => (
            <div key={patient.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center space-x-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-blue-100 text-blue-600">{patient.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium">{patient.name}</h4>
                  <p className="text-sm text-gray-600">{patient.condition}</p>
                  <p className="text-xs text-gray-500">{patient.time}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge
                  variant={
                    patient.status === "Completed"
                      ? "default"
                      : patient.status === "In Progress"
                        ? "secondary"
                        : "outline"
                  }
                >
                  {patient.status}
                </Badge>
                <Button variant="outline" size="sm">
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
