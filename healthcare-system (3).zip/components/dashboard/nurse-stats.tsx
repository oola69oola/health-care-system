import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, Thermometer, Heart, Clock } from "lucide-react"

const stats = [
  {
    title: "Vitals Recorded",
    value: "32",
    change: "+8 today",
    changeType: "positive" as const,
    icon: Activity,
  },
  {
    title: "Temperature Checks",
    value: "28",
    change: "All normal",
    changeType: "positive" as const,
    icon: Thermometer,
  },
  {
    title: "BP Monitoring",
    value: "15",
    change: "3 high readings",
    changeType: "neutral" as const,
    icon: Heart,
  },
  {
    title: "Medication Due",
    value: "12",
    change: "Next in 30 min",
    changeType: "neutral" as const,
    icon: Clock,
  },
]

export function NurseStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat) => (
        <Card key={stat.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
            <stat.icon className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
            <p
              className={`text-xs ${
                stat.changeType === "positive"
                  ? "text-green-600"
                  : stat.changeType === "negative"
                    ? "text-red-600"
                    : "text-gray-600"
              }`}
            >
              {stat.change}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
