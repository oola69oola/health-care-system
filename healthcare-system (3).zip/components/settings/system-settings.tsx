"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Settings, Database, Shield, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function SystemSettings() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [systemConfig, setSystemConfig] = useState({
    sessionTimeout: "3600",
    maxFileSize: "10",
    dataRetention: "2555",
    auditLogging: true,
    autoBackup: true,
    maintenanceMode: false,
  })

  const handleConfigChange = (field: string, value: string | boolean) => {
    setSystemConfig((prev) => ({ ...prev, [field]: value }))
  }

  const handleSaveSettings = async () => {
    setIsLoading(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "System Settings Updated",
        description: "All system configurations have been saved successfully.",
      })
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "There was an error updating system settings.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>General Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sessionTimeout">Session Timeout (seconds)</Label>
              <Input
                id="sessionTimeout"
                type="number"
                value={systemConfig.sessionTimeout}
                onChange={(e) => handleConfigChange("sessionTimeout", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxFileSize">Max File Upload Size (MB)</Label>
              <Input
                id="maxFileSize"
                type="number"
                value={systemConfig.maxFileSize}
                onChange={(e) => handleConfigChange("maxFileSize", e.target.value)}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="dataRetention">Data Retention Period (days)</Label>
              <Input
                id="dataRetention"
                type="number"
                value={systemConfig.dataRetention}
                onChange={(e) => handleConfigChange("dataRetention", e.target.value)}
              />
              <p className="text-sm text-gray-600">Default: 2555 days (7 years) for NDPR compliance</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security & Compliance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Security & Compliance</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Audit Logging</h4>
              <p className="text-sm text-gray-600">Enable comprehensive system audit logging</p>
            </div>
            <Switch
              checked={systemConfig.auditLogging}
              onCheckedChange={(checked) => handleConfigChange("auditLogging", checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Automatic Backup</h4>
              <p className="text-sm text-gray-600">Enable daily automatic database backups</p>
            </div>
            <Switch
              checked={systemConfig.autoBackup}
              onCheckedChange={(checked) => handleConfigChange("autoBackup", checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Maintenance Mode</h4>
              <p className="text-sm text-gray-600">Put system in maintenance mode</p>
            </div>
            <Switch
              checked={systemConfig.maintenanceMode}
              onCheckedChange={(checked) => handleConfigChange("maintenanceMode", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Database Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="h-5 w-5" />
            <span>Database Management</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button variant="outline">
              <Database className="h-4 w-4 mr-2" />
              Backup Database
            </Button>
            <Button variant="outline">
              <Database className="h-4 w-4 mr-2" />
              Restore Database
            </Button>
            <Button variant="outline">
              <Database className="h-4 w-4 mr-2" />
              Optimize Database
            </Button>
            <Button variant="outline">
              <Database className="h-4 w-4 mr-2" />
              View Logs
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            "Save All Settings"
          )}
        </Button>
      </div>
    </div>
  )
}
