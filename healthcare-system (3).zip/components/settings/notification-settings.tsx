"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Bell } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function NotificationSettings() {
  const { toast } = useToast()
  const [notifications, setNotifications] = useState({
    newMessages: true,
    referralUpdates: true,
    patientAlerts: true,
    systemUpdates: false,
    emailNotifications: true,
    smsNotifications: false,
  })

  const handleToggle = (setting: string, value: boolean) => {
    setNotifications((prev) => ({ ...prev, [setting]: value }))
    toast({
      title: "Notification Setting Updated",
      description: `${setting} notifications have been ${value ? "enabled" : "disabled"}.`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Bell className="h-5 w-5" />
          <span>Notification Preferences</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">New Messages</h4>
            <p className="text-sm text-gray-600">Get notified when you receive new messages</p>
          </div>
          <Switch
            checked={notifications.newMessages}
            onCheckedChange={(checked) => handleToggle("newMessages", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">Referral Updates</h4>
            <p className="text-sm text-gray-600">Notifications for referral status changes</p>
          </div>
          <Switch
            checked={notifications.referralUpdates}
            onCheckedChange={(checked) => handleToggle("referralUpdates", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">Patient Alerts</h4>
            <p className="text-sm text-gray-600">Critical patient updates and alerts</p>
          </div>
          <Switch
            checked={notifications.patientAlerts}
            onCheckedChange={(checked) => handleToggle("patientAlerts", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">System Updates</h4>
            <p className="text-sm text-gray-600">System maintenance and update notifications</p>
          </div>
          <Switch
            checked={notifications.systemUpdates}
            onCheckedChange={(checked) => handleToggle("systemUpdates", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">Email Notifications</h4>
            <p className="text-sm text-gray-600">Receive notifications via email</p>
          </div>
          <Switch
            checked={notifications.emailNotifications}
            onCheckedChange={(checked) => handleToggle("emailNotifications", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">SMS Notifications</h4>
            <p className="text-sm text-gray-600">Receive notifications via SMS</p>
          </div>
          <Switch
            checked={notifications.smsNotifications}
            onCheckedChange={(checked) => handleToggle("smsNotifications", checked)}
          />
        </div>
      </CardContent>
    </Card>
  )
}
