"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent } from "@/components/ui/sheet"
import {
  Hospital,
  Users,
  FileText,
  MessageSquare,
  Settings,
  LogOut,
  Menu,
  Bell,
  Search,
  Activity,
  TestTube,
  Pill,
  Shield,
  Package,
} from "lucide-react"
import { Input } from "@/components/ui/input"

const getNavigationForRole = (role: string) => {
  const baseNavigation = [
    { name: "Dashboard", href: `/dashboard/${role}`, icon: Hospital },
    { name: "Messages", href: "/messages", icon: MessageSquare },
    { name: "Settings", href: "/settings", icon: Settings },
  ]

  const roleSpecificNavigation = {
    doctor: [
      { name: "Patients", href: "/patients", icon: Users },
      { name: "Referrals", href: "/referrals", icon: FileText },
    ],
    nurse: [
      { name: "Patients", href: "/patients", icon: Users },
      { name: "Vitals", href: "/vitals", icon: Activity },
    ],
    admin: [
      { name: "Users", href: "/users", icon: Users },
      { name: "System", href: "/system", icon: Shield },
      { name: "Reports", href: "/reports", icon: FileText },
    ],
    "lab-tech": [
      { name: "Tests", href: "/tests", icon: TestTube },
      { name: "Results", href: "/results", icon: FileText },
    ],
    pharmacist: [
      { name: "Prescriptions", href: "/prescriptions", icon: Pill },
      { name: "Inventory", href: "/inventory", icon: Package },
    ],
  }

  return [
    baseNavigation[0], // Dashboard first
    ...(roleSpecificNavigation[role as keyof typeof roleSpecificNavigation] || []),
    ...baseNavigation.slice(1), // Messages and Settings last
  ]
}

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  if (!user) return null

  const navigation = getNavigationForRole(user.role)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-64">
          <SidebarContent navigation={navigation} user={user} onLogout={handleLogout} />
        </SheetContent>
      </Sheet>

      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col">
        <div className="flex min-h-0 flex-1 flex-col bg-white border-r border-gray-200">
          <SidebarContent navigation={navigation} user={user} onLogout={handleLogout} />
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64 flex flex-col flex-1">
        {/* Top bar */}
        <div className="sticky top-0 z-10 flex h-16 bg-white border-b border-gray-200 lg:border-none">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
            <Menu className="h-6 w-6" />
          </Button>

          <div className="flex flex-1 justify-between px-4 lg:px-6">
            <div className="flex flex-1 items-center">
              <div className="w-full max-w-lg">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input placeholder="Search patients, records, referrals..." className="pl-10" />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <div className="text-sm">
                <p className="font-medium text-gray-900">{user.name}</p>
                <p className="text-gray-500 capitalize">{user.role}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

function SidebarContent({ navigation, user, onLogout }: { navigation: any[]; user: any; onLogout: () => void }) {
  return (
    <>
      <div className="flex items-center h-16 px-6 border-b border-gray-200">
        <Hospital className="h-8 w-8 text-blue-600" />
        <span className="ml-2 text-xl font-semibold text-gray-900">PHC System</span>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="px-4 py-4 border-b border-gray-200">
          <div className="text-sm">
            <p className="font-medium text-gray-900">{user.name}</p>
            <p className="text-gray-500">{user.center}</p>
            <p className="text-xs text-blue-600 capitalize">{user.role}</p>
          </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 rounded-md hover:bg-gray-100 hover:text-gray-900 transition-colors"
            >
              <item.icon className="mr-3 h-5 w-5" />
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-200">
          <Button
            variant="ghost"
            className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={onLogout}
          >
            <LogOut className="mr-3 h-5 w-5" />
            Sign Out
          </Button>
        </div>
      </div>
    </>
  )
}
