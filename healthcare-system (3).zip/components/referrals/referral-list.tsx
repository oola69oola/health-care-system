"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Eye, MessageSquare, CheckCircle, Loader2 } from "lucide-react"
import { useState } from "react"

const mockReferrals = [
  {
    id: "1",
    patient: "Adunni Olatunji",
    patientInitials: "AO",
    fromCenter: "Agodi PHC",
    toCenter: "Bodija PHC",
    reason: "Specialist cardiology consultation",
    status: "Pending",
    priority: "High",
    referredBy: "Dr. Adebayo Johnson",
    referredDate: "2024-01-15",
    expectedDate: "2024-01-20",
  },
  {
    id: "2",
    patient: "Tunde Ogundimu",
    patientInitials: "TO",
    fromCenter: "Mokola PHC",
    toCenter: "Agodi PHC",
    reason: "Diabetes management and monitoring",
    status: "In Progress",
    priority: "Medium",
    referredBy: "Dr. Fatima Bello",
    referredDate: "2024-01-12",
    expectedDate: "2024-01-18",
  },
  {
    id: "3",
    patient: "Kemi Adebayo",
    patientInitials: "KA",
    fromCenter: "Sango PHC",
    toCenter: "Inalende PHC",
    reason: "Prenatal care and monitoring",
    status: "Completed",
    priority: "Medium",
    referredBy: "Dr. Aisha Mahmud",
    referredDate: "2024-01-08",
    expectedDate: "2024-01-15",
  },
]

export function ReferralList() {
  const [loadingStates, setLoadingStates] = useState<{ [key: string]: boolean }>({})

  const handleButtonClick = async (action: string, referralId: string) => {
    const key = `${action}-${referralId}`
    setLoadingStates((prev) => ({ ...prev, [key]: true }))

    try {
      await new Promise((resolve) => setTimeout(resolve, 500))
      // Handle the action here
    } finally {
      setLoadingStates((prev) => ({ ...prev, [key]: false }))
    }
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Referrals</p>
                <p className="text-2xl font-bold">23</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Eye className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-orange-600">8</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-full">
                <MessageSquare className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Progress</p>
                <p className="text-2xl font-bold text-blue-600">7</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Eye className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-green-600">8</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Referrals List */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Referrals</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockReferrals.map((referral) => (
              <div key={referral.id} className="p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-blue-100 text-blue-600">{referral.patientInitials}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-semibold text-gray-900">{referral.patient}</h3>
                        <Badge
                          variant={
                            referral.priority === "High"
                              ? "destructive"
                              : referral.priority === "Medium"
                                ? "default"
                                : "secondary"
                          }
                        >
                          {referral.priority} Priority
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{referral.reason}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>From: {referral.fromCenter}</span>
                        <span>→</span>
                        <span>To: {referral.toCenter}</span>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                        <span>Referred by: {referral.referredBy}</span>
                        <span>•</span>
                        <span>Date: {referral.referredDate}</span>
                        <span>•</span>
                        <span>Expected: {referral.expectedDate}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Badge
                      variant={
                        referral.status === "Completed"
                          ? "default"
                          : referral.status === "In Progress"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {referral.status}
                    </Badge>

                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleButtonClick("view", referral.id)}
                        disabled={loadingStates[`view-${referral.id}`]}
                      >
                        {loadingStates[`view-${referral.id}`] ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleButtonClick("message", referral.id)}
                        disabled={loadingStates[`message-${referral.id}`]}
                      >
                        {loadingStates[`message-${referral.id}`] ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <MessageSquare className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
