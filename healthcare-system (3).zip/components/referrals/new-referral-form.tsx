"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Send, Loader2, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const mockPatients = [
  { id: "1", name: "Adunni Olatunji", age: 34, condition: "Hypertension" },
  { id: "2", name: "Tunde Ogundimu", age: 45, condition: "Diabetes" },
  { id: "3", name: "Kemi Adebayo", age: 28, condition: "Pregnancy" },
]

const phcCenters = [
  { id: "1", name: "Agodi PHC Center", specialties: ["General Medicine", "Pediatrics"] },
  { id: "2", name: "Bodija PHC Center", specialties: ["Cardiology", "Internal Medicine"] },
  { id: "3", name: "Inalende PHC Center", specialties: ["Obstetrics", "Gynecology"] },
  { id: "4", name: "Mokola PHC Center", specialties: ["Orthopedics", "General Surgery"] },
  { id: "5", name: "Sango PHC Center", specialties: ["Pediatrics", "Family Medicine"] },
]

interface ReferralFormData {
  patientId: string
  receivingCenter: string
  specialty: string
  urgency: string
  reason: string
  clinicalSummary: string
  expectedDate: string
}

export function NewReferralForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [patientSearch, setPatientSearch] = useState("")
  const [formData, setFormData] = useState<ReferralFormData>({
    patientId: "",
    receivingCenter: "",
    specialty: "",
    urgency: "",
    reason: "",
    clinicalSummary: "",
    expectedDate: "",
  })

  const filteredPatients = mockPatients.filter((patient) =>
    patient.name.toLowerCase().includes(patientSearch.toLowerCase()),
  )

  const selectedCenter = phcCenters.find((center) => center.id === formData.receivingCenter)

  const handleInputChange = (field: keyof ReferralFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Referral Created Successfully",
        description: "The referral has been sent to the receiving center.",
      })

      setTimeout(() => {
        router.push("/referrals")
      }, 1000)
    } catch (error) {
      toast({
        title: "Referral Failed",
        description: "There was an error creating the referral. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const isFormValid =
    formData.patientId && formData.receivingCenter && formData.urgency && formData.reason && formData.clinicalSummary

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Patient Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Patient Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="patientSearch">Search Patient</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="patientSearch"
                  placeholder="Search by patient name..."
                  value={patientSearch}
                  onChange={(e) => setPatientSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="patient">Select Patient *</Label>
              <Select value={formData.patientId} onValueChange={(value) => handleInputChange("patientId", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose patient to refer" />
                </SelectTrigger>
                <SelectContent>
                  {filteredPatients.map((patient) => (
                    <SelectItem key={patient.id} value={patient.id}>
                      {patient.name} - {patient.age}y ({patient.condition})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="urgency">Urgency Level *</Label>
              <Select value={formData.urgency} onValueChange={(value) => handleInputChange("urgency", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select urgency level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Low">Low - Routine</SelectItem>
                  <SelectItem value="Medium">Medium - Within 1 week</SelectItem>
                  <SelectItem value="High">High - Within 24 hours</SelectItem>
                  <SelectItem value="Emergency">Emergency - Immediate</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="expectedDate">Expected Date</Label>
              <Input
                id="expectedDate"
                type="date"
                value={formData.expectedDate}
                onChange={(e) => handleInputChange("expectedDate", e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Receiving Center */}
        <Card>
          <CardHeader>
            <CardTitle>Receiving Center</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="receivingCenter">PHC Center *</Label>
              <Select
                value={formData.receivingCenter}
                onValueChange={(value) => handleInputChange("receivingCenter", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select receiving center" />
                </SelectTrigger>
                <SelectContent>
                  {phcCenters.map((center) => (
                    <SelectItem key={center.id} value={center.id}>
                      {center.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedCenter && (
              <div className="space-y-2">
                <Label htmlFor="specialty">Available Specialties</Label>
                <Select value={formData.specialty} onValueChange={(value) => handleInputChange("specialty", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select specialty" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedCenter.specialties.map((specialty) => (
                      <SelectItem key={specialty} value={specialty}>
                        {specialty}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="reason">Reason for Referral *</Label>
              <Textarea
                id="reason"
                placeholder="Brief reason for referral..."
                value={formData.reason}
                onChange={(e) => handleInputChange("reason", e.target.value)}
                rows={3}
                required
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Clinical Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Clinical Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="clinicalSummary">Detailed Clinical Information *</Label>
            <Textarea
              id="clinicalSummary"
              placeholder="Include relevant medical history, current symptoms, medications, test results, and any other pertinent clinical information..."
              value={formData.clinicalSummary}
              onChange={(e) => handleInputChange("clinicalSummary", e.target.value)}
              rows={6}
              required
            />
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={() => router.back()} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button type="submit" disabled={!isFormValid || isSubmitting} className="min-w-[140px]">
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Create Referral
            </>
          )}
        </Button>
      </div>
    </form>
  )
}
