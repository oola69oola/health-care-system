"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useState } from "react"
import { Send, Edit, FileText, Loader2 } from "lucide-react"

interface PatientDetailsModalProps {
  patient: any
  isOpen: boolean
  onClose: () => void
}

export function PatientDetailsModal({ patient, isOpen, onClose }: PatientDetailsModalProps) {
  const [loadingStates, setLoadingStates] = useState<{ [key: string]: boolean }>({})

  const handleButtonClick = async (action: string) => {
    setLoadingStates((prev) => ({ ...prev, [action]: true }))

    try {
      await new Promise((resolve) => setTimeout(resolve, 500))
      // Handle the action here
    } finally {
      setLoadingStates((prev) => ({ ...prev, [action]: false }))
    }
  }

  if (!patient) return null

  const medicalHistory = [
    { date: "2024-01-15", diagnosis: "Hypertension follow-up", doctor: "Dr. Adebayo", center: "Agodi PHC" },
    { date: "2023-12-20", diagnosis: "Annual check-up", doctor: "Dr. Fatima", center: "Agodi PHC" },
    { date: "2023-11-15", diagnosis: "Blood pressure monitoring", doctor: "Dr. Adebayo", center: "Agodi PHC" },
  ]

  const vitals = [
    { parameter: "Blood Pressure", value: "140/90 mmHg", status: "High", date: "2024-01-15" },
    { parameter: "Heart Rate", value: "78 bpm", status: "Normal", date: "2024-01-15" },
    { parameter: "Temperature", value: "36.5°C", status: "Normal", date: "2024-01-15" },
    { parameter: "Weight", value: "68 kg", status: "Normal", date: "2024-01-15" },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16">
                <AvatarFallback className="bg-blue-100 text-blue-600 text-lg">{patient.initials}</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-2xl font-bold">{patient.name}</h2>
                <p className="text-gray-600">
                  {patient.age} years • {patient.gender}
                </p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleButtonClick("edit")}
                disabled={loadingStates.edit}
              >
                {loadingStates.edit ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Edit className="h-4 w-4 mr-2" />
                )}
                Edit
              </Button>
              <Button size="sm" onClick={() => handleButtonClick("refer")} disabled={loadingStates.refer}>
                {loadingStates.refer ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Send className="h-4 w-4 mr-2" />
                )}
                Refer
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="history">Medical History</TabsTrigger>
            <TabsTrigger value="vitals">Vitals</TabsTrigger>
            <TabsTrigger value="referrals">Referrals</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Patient Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Phone:</span>
                    <span className="font-medium">{patient.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Visit:</span>
                    <span className="font-medium">{patient.lastVisit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <Badge variant={patient.status === "Active" ? "default" : "secondary"}>{patient.status}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Primary Center:</span>
                    <span className="font-medium">{patient.center}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Current Condition</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <span className="text-gray-600">Primary Diagnosis:</span>
                      <p className="font-medium text-lg">{patient.condition}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Treatment Plan:</span>
                      <p className="text-sm">Regular monitoring, medication compliance, lifestyle modifications</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Medical History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {medicalHistory.map((record, index) => (
                    <div key={index} className="flex items-start space-x-4 p-4 border rounded-lg">
                      <div className="bg-blue-100 p-2 rounded-full">
                        <FileText className="h-4 w-4 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{record.diagnosis}</h4>
                            <p className="text-sm text-gray-600">
                              {record.doctor} • {record.center}
                            </p>
                          </div>
                          <span className="text-sm text-gray-500">{record.date}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="vitals" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Latest Vital Signs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {vitals.map((vital, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium">{vital.parameter}</h4>
                        <Badge variant={vital.status === "Normal" ? "default" : "destructive"}>{vital.status}</Badge>
                      </div>
                      <p className="text-2xl font-bold">{vital.value}</p>
                      <p className="text-sm text-gray-500">Recorded on {vital.date}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="referrals" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Referral History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-medium">Specialist Consultation</h4>
                        <p className="text-sm text-gray-600">Referred to Bodija PHC - Cardiology</p>
                      </div>
                      <Badge variant="secondary">Pending</Badge>
                    </div>
                    <p className="text-sm text-gray-500">Referred on 2024-01-15 by Dr. Adebayo</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
