"use client"

import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search } from "lucide-react"

interface PatientFiltersProps {
  filters: {
    search: string
    status: string
    center: string
  }
  onFiltersChange: (filters: any) => void
}

export function PatientFilters({ filters, onFiltersChange }: PatientFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-4">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search patients by name or phone..."
          value={filters.search}
          onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
          className="pl-10"
        />
      </div>

      <Select value={filters.status} onValueChange={(value) => onFiltersChange({ ...filters, status: value })}>
        <SelectTrigger className="w-full sm:w-48">
          <SelectValue placeholder="Filter by status" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Status</SelectItem>
          <SelectItem value="active">Active</SelectItem>
          <SelectItem value="follow-up">Follow-up</SelectItem>
          <SelectItem value="referred">Referred</SelectItem>
        </SelectContent>
      </Select>

      <Select value={filters.center} onValueChange={(value) => onFiltersChange({ ...filters, center: value })}>
        <SelectTrigger className="w-full sm:w-48">
          <SelectValue placeholder="Filter by center" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Centers</SelectItem>
          <SelectItem value="Agodi PHC">Agodi PHC</SelectItem>
          <SelectItem value="Bodija PHC">Bodija PHC</SelectItem>
          <SelectItem value="Inalende PHC">Inalende PHC</SelectItem>
          <SelectItem value="Mokola PHC">Mokola PHC</SelectItem>
          <SelectItem value="Sango PHC">Sango PHC</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}
