"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Eye, Edit, Send } from "lucide-react"
import { PatientDetailsModal } from "./patient-details-modal"

const mockPatients = [
  {
    id: "1",
    name: "Adunni Olatunji",
    age: 34,
    gender: "Female",
    phone: "+234 803 123 4567",
    lastVisit: "2024-01-15",
    status: "Active",
    center: "Agodi PHC",
    condition: "Hypertension",
    initials: "AO",
  },
  {
    id: "2",
    name: "Tunde Ogundimu",
    age: 45,
    gender: "Male",
    phone: "+234 805 987 6543",
    lastVisit: "2024-01-12",
    status: "Follow-up",
    center: "Bodija PHC",
    condition: "Diabetes",
    initials: "TO",
  },
  {
    id: "3",
    name: "Kemi Adebayo",
    age: 28,
    gender: "Female",
    phone: "+234 807 456 7890",
    lastVisit: "2024-01-10",
    status: "Active",
    center: "Agodi PHC",
    condition: "Pregnancy Care",
    initials: "KA",
  },
  {
    id: "4",
    name: "Bisi Afolabi",
    age: 52,
    gender: "Female",
    phone: "+234 809 234 5678",
    lastVisit: "2024-01-08",
    status: "Referred",
    center: "Mokola PHC",
    condition: "Cardiac Assessment",
    initials: "BA",
  },
]

interface PatientListProps {
  filters: {
    search: string
    status: string
    center: string
  }
}

export function PatientList({ filters }: PatientListProps) {
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [loadingStates, setLoadingStates] = useState<{ [key: string]: boolean }>({})

  const handleButtonClick = async (action: string, patientId: string, callback?: () => void) => {
    const key = `${action}-${patientId}`
    setLoadingStates((prev) => ({ ...prev, [key]: true }))

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500))
      callback?.()
    } finally {
      setLoadingStates((prev) => ({ ...prev, [key]: false }))
    }
  }

  const filteredPatients = mockPatients.filter((patient) => {
    const matchesSearch =
      patient.name.toLowerCase().includes(filters.search.toLowerCase()) || patient.phone.includes(filters.search)
    const matchesStatus = filters.status === "all" || patient.status.toLowerCase() === filters.status
    const matchesCenter = filters.center === "all" || patient.center === filters.center

    return matchesSearch && matchesStatus && matchesCenter
  })

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Patient Records ({filteredPatients.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredPatients.map((patient) => (
              <div
                key={patient.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center space-x-4">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-blue-100 text-blue-600">{patient.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-gray-900">{patient.name}</h3>
                    <p className="text-sm text-gray-600">
                      {patient.age} years • {patient.gender} • {patient.phone}
                    </p>
                    <p className="text-sm text-gray-500">
                      Last visit: {patient.lastVisit} • {patient.condition}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Badge
                    variant={
                      patient.status === "Active" ? "default" : patient.status === "Follow-up" ? "secondary" : "outline"
                    }
                  >
                    {patient.status}
                  </Badge>

                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleButtonClick("view", patient.id, () => setSelectedPatient(patient))}
                      disabled={loadingStates[`view-${patient.id}`]}
                    >
                      {loadingStates[`view-${patient.id}`] ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleButtonClick("edit", patient.id)}
                      disabled={loadingStates[`edit-${patient.id}`]}
                    >
                      {loadingStates[`edit-${patient.id}`] ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600" />
                      ) : (
                        <Edit className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleButtonClick("refer", patient.id)}
                      disabled={loadingStates[`refer-${patient.id}`]}
                    >
                      {loadingStates[`refer-${patient.id}`] ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {selectedPatient && (
        <PatientDetailsModal
          patient={selectedPatient}
          isOpen={!!selectedPatient}
          onClose={() => setSelectedPatient(null)}
        />
      )}
    </>
  )
}
