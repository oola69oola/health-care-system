"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Send, Search, Phone, Video, Loader2 } from "lucide-react"

const conversations = [
  {
    id: "1",
    name: "Dr. Fatima Bello",
    center: "Bodija PHC",
    lastMessage: "Patient referral completed successfully",
    time: "2 min ago",
    unread: 2,
    initials: "FB",
    online: true,
  },
  {
    id: "2",
    name: "Nurse Aisha Mahmud",
    center: "Sango PHC",
    lastMessage: "Lab results are ready for review",
    time: "15 min ago",
    unread: 0,
    initials: "AM",
    online: true,
  },
  {
    id: "3",
    name: "Dr. Kemi Ogundimu",
    center: "Mokola PHC",
    lastMessage: "Thanks for the consultation notes",
    time: "1 hour ago",
    unread: 0,
    initials: "KO",
    online: false,
  },
  {
    id: "4",
    name: "Admin Team",
    center: "System",
    lastMessage: "System maintenance scheduled for tonight",
    time: "2 hours ago",
    unread: 1,
    initials: "AT",
    online: true,
  },
]

const messages = [
  {
    id: "1",
    sender: "Dr. Fatima Bello",
    content: "Hello! I wanted to update you on the patient referral for Adunni Olatunji.",
    time: "10:30 AM",
    isOwn: false,
  },
  {
    id: "2",
    sender: "You",
    content: "Great! How did the consultation go?",
    time: "10:32 AM",
    isOwn: true,
  },
  {
    id: "3",
    sender: "Dr. Fatima Bello",
    content:
      "The patient responded well to the treatment plan. Her blood pressure is now under control. I've updated her records with the new medication dosage.",
    time: "10:35 AM",
    isOwn: false,
  },
  {
    id: "4",
    sender: "You",
    content: "Excellent news! Should we schedule a follow-up appointment?",
    time: "10:37 AM",
    isOwn: true,
  },
  {
    id: "5",
    sender: "Dr. Fatima Bello",
    content: "Yes, I recommend a follow-up in 2 weeks. I'll coordinate with her primary care schedule.",
    time: "10:40 AM",
    isOwn: false,
  },
]

export function MessagingInterface() {
  const [selectedConversation, setSelectedConversation] = useState(conversations[0])
  const [newMessage, setNewMessage] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [buttonLoading, setButtonLoading] = useState<{ [key: string]: boolean }>({})

  const filteredConversations = conversations.filter(
    (conv) =>
      conv.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      conv.center.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    // In a real app, send message to backend
    console.log("Sending message:", newMessage)
    setNewMessage("")
  }

  const handleButtonClick = async (action: string, callback?: () => void) => {
    setButtonLoading((prev) => ({ ...prev, [action]: true }))

    try {
      await new Promise((resolve) => setTimeout(resolve, 500))
      callback?.()
    } finally {
      setButtonLoading((prev) => ({ ...prev, [action]: false }))
    }
  }

  return (
    <div className="flex h-full space-x-4">
      {/* Conversations List */}
      <Card className="w-1/3 flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Messages
            <Badge variant="secondary">{conversations.filter((c) => c.unread > 0).length}</Badge>
          </CardTitle>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-0">
          <div className="space-y-1">
            {filteredConversations.map((conversation) => (
              <div
                key={conversation.id}
                className={`p-4 cursor-pointer hover:bg-gray-50 border-b ${
                  selectedConversation.id === conversation.id ? "bg-blue-50 border-l-4 border-l-blue-500" : ""
                }`}
                onClick={() => setSelectedConversation(conversation)}
              >
                <div className="flex items-start space-x-3">
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-blue-100 text-blue-600">{conversation.initials}</AvatarFallback>
                    </Avatar>
                    {conversation.online && (
                      <div className="absolute -bottom-1 -right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-white"></div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-gray-900 truncate">{conversation.name}</h4>
                      <div className="flex items-center space-x-2">
                        {conversation.unread > 0 && (
                          <Badge variant="destructive" className="text-xs">
                            {conversation.unread}
                          </Badge>
                        )}
                        <span className="text-xs text-gray-500">{conversation.time}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 truncate">{conversation.center}</p>
                    <p className="text-sm text-gray-500 truncate">{conversation.lastMessage}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Chat Interface */}
      <Card className="flex-1 flex flex-col">
        {/* Chat Header */}
        <CardHeader className="border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-blue-100 text-blue-600">{selectedConversation.initials}</AvatarFallback>
                </Avatar>
                {selectedConversation.online && (
                  <div className="absolute -bottom-1 -right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-white"></div>
                )}
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{selectedConversation.name}</h3>
                <p className="text-sm text-gray-600">{selectedConversation.center}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleButtonClick("phone")}
                disabled={buttonLoading.phone}
              >
                {buttonLoading.phone ? <Loader2 className="h-4 w-4 animate-spin" /> : <Phone className="h-4 w-4" />}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleButtonClick("video")}
                disabled={buttonLoading.video}
              >
                {buttonLoading.video ? <Loader2 className="h-4 w-4 animate-spin" /> : <Video className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </CardHeader>

        {/* Messages */}
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                  message.isOwn ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-900"
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className={`text-xs mt-1 ${message.isOwn ? "text-blue-100" : "text-gray-500"}`}>{message.time}</p>
              </div>
            </div>
          ))}
        </CardContent>

        {/* Message Input */}
        <div className="border-t p-4">
          <form onSubmit={handleSendMessage} className="flex space-x-2">
            <Input
              placeholder="Type your message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" disabled={!newMessage.trim() || isLoading} className="min-w-[60px]">
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </form>
        </div>
      </Card>
    </div>
  )
}
