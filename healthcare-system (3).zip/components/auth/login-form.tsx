"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, Hospital, Loader2 } from "lucide-react"

const mockUsers = [
  {
    id: "1",
    email: "dr.adebayo@phc.oyo.gov.ng",
    password: "doctor123",
    name: "Dr. Adebayo Johnson",
    role: "doctor",
    center: "Agodi PHC Center",
  },
  {
    id: "2",
    email: "nurse.aisha@phc.oyo.gov.ng",
    password: "nurse123",
    name: "Nurse Aisha Mahmud",
    role: "nurse",
    center: "Sango PHC Center",
  },
  {
    id: "3",
    email: "admin.system@phc.oyo.gov.ng",
    password: "admin123",
    name: "System Administrator",
    role: "admin",
    center: "Agodi PHC Center",
  },
  {
    id: "4",
    email: "lab.tech@phc.oyo.gov.ng",
    password: "lab123",
    name: "Lab Technician Kemi",
    role: "lab-tech",
    center: "Bodija PHC Center",
  },
  {
    id: "5",
    email: "pharmacist@phc.oyo.gov.ng",
    password: "pharm123",
    name: "Pharmacist Tunde",
    role: "pharmacist",
    center: "Mokola PHC Center",
  },
]

export function LoginForm() {
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
    role: "",
    center: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Find matching user
      const user = mockUsers.find(
        (u) => u.email === credentials.email && u.password === credentials.password && u.role === credentials.role,
      )

      if (!user) {
        alert("Invalid credentials. Please check your email, password, and role.")
        return
      }

      // Store user data
      localStorage.setItem("user", JSON.stringify(user))

      // Redirect based on role
      const dashboardRoutes = {
        doctor: "/dashboard/doctor",
        nurse: "/dashboard/nurse",
        admin: "/dashboard/admin",
        "lab-tech": "/dashboard/lab-tech",
        pharmacist: "/dashboard/pharmacist",
      }

      router.push(dashboardRoutes[user.role as keyof typeof dashboardRoutes] || "/dashboard")
    } catch (error) {
      alert("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader className="space-y-1">
        <div className="flex items-center justify-center mb-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Hospital className="h-8 w-8 text-blue-600" />
          </div>
        </div>
        <CardTitle className="text-2xl text-center">Sign In</CardTitle>
        <CardDescription className="text-center">Access the healthcare collaboration platform</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="doctor@phc.gov.ng"
              value={credentials.email}
              onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={credentials.password}
              onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Role</Label>
            <Select value={credentials.role} onValueChange={(value) => setCredentials({ ...credentials, role: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select your role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="doctor">Doctor</SelectItem>
                <SelectItem value="nurse">Nurse</SelectItem>
                <SelectItem value="admin">Administrator</SelectItem>
                <SelectItem value="lab-tech">Lab Technician</SelectItem>
                <SelectItem value="pharmacist">Pharmacist</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="center">PHC Center</Label>
            <Select
              value={credentials.center}
              onValueChange={(value) => setCredentials({ ...credentials, center: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select your center" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="agodi">Agodi PHC Center</SelectItem>
                <SelectItem value="bodija">Bodija PHC Center</SelectItem>
                <SelectItem value="inalende">Inalende PHC Center</SelectItem>
                <SelectItem value="mokola">Mokola PHC Center</SelectItem>
                <SelectItem value="sango">Sango PHC Center</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={
              !credentials.email || !credentials.password || !credentials.role || !credentials.center || isLoading
            }
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Signing In...
              </>
            ) : (
              <>
                <Shield className="mr-2 h-4 w-4" />
                Sign In Securely
              </>
            )}
          </Button>
        </form>

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <p className="text-sm font-medium text-gray-700 mb-2">Demo Credentials:</p>
          <div className="text-xs text-gray-600 space-y-1">
            <p>
              <strong>Doctor:</strong> dr.adebayo@phc.oyo.gov.ng / doctor123
            </p>
            <p>
              <strong>Nurse:</strong> nurse.aisha@phc.oyo.gov.ng / nurse123
            </p>
            <p>
              <strong>Admin:</strong> admin.system@phc.oyo.gov.ng / admin123
            </p>
            <p>
              <strong>Lab Tech:</strong> lab.tech@phc.oyo.gov.ng / lab123
            </p>
            <p>
              <strong>Pharmacist:</strong> pharmacist@phc.oyo.gov.ng / pharm123
            </p>
          </div>
        </div>

        <div className="mt-4 text-center text-sm text-gray-600">
          <p>Protected by NDPR-compliant security measures</p>
        </div>
      </CardContent>
    </Card>
  )
}
