"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, X } from "lucide-react"

export function NDPRBanner() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const hasAccepted = localStorage.getItem("ndpr-consent")
    if (!hasAccepted) {
      setIsVisible(true)
    }
  }, [])

  const handleAccept = () => {
    localStorage.setItem("ndpr-consent", "true")
    localStorage.setItem("ndpr-consent-date", new Date().toISOString())
    setIsVisible(false)
  }

  const handleDecline = () => {
    // In a real app, this would redirect to a page explaining why consent is needed
    alert("Data consent is required to use this healthcare system in compliance with NDPR.")
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 md:left-auto md:right-4 md:max-w-md">
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-semibold text-blue-900 mb-2">Data Privacy Notice (NDPR)</h4>
              <p className="text-sm text-blue-800 mb-3">
                We collect and process your health data in compliance with the Nigerian Data Protection Regulation
                (NDPR) to provide healthcare services. Your data is encrypted and securely stored.
              </p>
              <div className="flex space-x-2">
                <Button size="sm" onClick={handleAccept}>
                  Accept
                </Button>
                <Button variant="outline" size="sm" onClick={handleDecline}>
                  Learn More
                </Button>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setIsVisible(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
